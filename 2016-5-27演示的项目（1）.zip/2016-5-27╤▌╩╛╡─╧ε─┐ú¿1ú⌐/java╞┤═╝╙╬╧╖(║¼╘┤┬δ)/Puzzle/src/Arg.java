public interface Arg
{
	public static final String path = "background";
	public static final String rc = "Game.rc";
}
