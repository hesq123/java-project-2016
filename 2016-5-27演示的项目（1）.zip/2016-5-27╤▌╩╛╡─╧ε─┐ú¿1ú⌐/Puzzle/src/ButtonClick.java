import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 * ������Ϊ��ť������
 * 
 * @author hesq
 *
 * 2016��5��27��
 */
public class ButtonClick implements ActionListener {
	private JButton[][] button;
	private point pint;
	private int row;
	private int col;
	private int[][] matrix;
	private GameOver gOver;
	private boolean end;

	public ButtonClick(JButton[][] b, point p, int[][] m, int r, int c, GameOver g) {
		button = b;
		pint = p;
		matrix = m;
		row = r;
		col = c;
		gOver = g;
		end = false;
	}

	public void actionPerformed(ActionEvent e) {
		if (end || !pint.neighbor(row, col))
			return;

		int r = pint.getRow();
		int c = pint.getCal();

		button[r][c].setIcon(button[row][col].getIcon());
		button[row][col].setIcon(null);
		pint.set(row, col);
		int t = matrix[r][c];
		matrix[r][c] = matrix[row][col];
		matrix[row][col] = t;
		end = gOver.judge();
	}
}
