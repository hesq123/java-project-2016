package tarena.emp.servlet;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tarena.emp.dao.DaoFactory;
import tarena.emp.dao.EmpDao;
import tarena.emp.dao.impl.EmpDaoJdbcImpl;
import tarena.emp.entity.Emp;

public class EmpListServlet extends HttpServlet {
	//    /emp/EmpListServlet
	
	protected void service(
			HttpServletRequest request, 
			HttpServletResponse response)
			throws ServletException, IOException {
		//add user
		response.setContentType(
				"text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		
		out.println("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">");
		out.println("<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\">");
		out.println(" ");
		out.println("<head>");
		out.println("<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" />");
		out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/layout2_setup.css\" />");
		out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/layout2_text.css\" />");
		out.println("<title></title>");
		out.println("</head>");
		out.println("");
		out.println("<!--[if IE]><style type=\"text/css\"> body {word-wrap: break-word;}</style><![endif]-->");
		out.println("");
		out.println("<body>");
		out.println("<div class=\"page-container\">");
		out.println("");
		out.println("");
		out.println("<div class=\"header\">");
		out.println(" ");
		out.println("<div class=\"header-middle\"> ");
		out.println(" ");
		out.println("<a class=\"sitelogo\" href=\"#\" title=\"Go to Start page\"></a>");
		out.println("<div class=\"sitename\">");
		out.println("<h1><a href=\"index.html\" title=\"Go to Start page\">TARENA<span style=\"font-weight:normal;font-size:50%;\">.com.cn</span></a></h1>");
		out.println("<h2>加拿大达内外企培训</h2>");
		out.println("</div>");
		out.println("");
		out.println("</div>");
		out.println(" ");
		out.println("<div class=\"header-bottom\">");
		out.println(" ");
		out.println("<div class=\"nav2\">");
		out.println(" ");
		out.println("<ul>");
		out.println("<li><a href=\"index.html\">系统首页</a></li>");
		out.println("</ul>");
		out.println(" ");
		out.println("<ul>");
		out.println("<li><a href=\"#\">员工管理<!--[if IE 7]><!--></a><!--<![endif]-->");
		out.println("<!--[if lte IE 6]><table><tr><td><![endif]-->");
		out.println("<ul>");
		out.println("<li><a href=\"#\">员工管理</a></li>");
		out.println("<li><a href=\"#\">添加员工</a></li>");
		out.println("</ul>");
		out.println("<!--[if lte IE 6]></td></tr></table></a><![endif]-->");
		out.println("</li>");
		out.println("</ul> ");
		out.println("");
		out.println("</div>");
		out.println("</div>");
		out.println("");
		out.println("");
		out.println("<div class=\"header-breadcrumbs\">");
		out.println("<ul>");
		out.println("<li><a href=\"#\">首页</a></li>");
		out.println("<li><a href=\"#\">员工管理</a></li>");
		out.println("<li>员工列表</li>");
		out.println("</ul>");
		out.println("");
		out.println(" ");
		out.println("</div>");
		out.println("</div>");
		out.println("");
		out.println("");
		out.println("<div class=\"main\">");
		out.println(" ");
		out.println("<div class=\"main-navigation\">");
		out.println("");
		out.println("<div class=\"round-border-topright\"></div>");
		out.println("<h1 class=\"first\">列表说明<br /></h1>");
		out.println("<p>表格内显示所有员工信息</p>");
		out.println(" ");
		out.println("");
		out.println("");
		out.println(" ");
		out.println("</div>");
		out.println(" ");
		out.println("<div class=\"main-content\">");
		out.println(" ");
		out.println("<h1 class=\"pagetitle\">员工列表</h1>");
		out.println("");
		out.println(" ");
		out.println("");
		out.println(" ");
		out.println("<div class=\"column1-unit\">");
		out.println("<table>");
		out.println("<tr><th class=\"top\" scope=\"col\">员工编号<br /></th><th class=\"top\" scope=\"col\">姓名</th><th class=\"top\" scope=\"col\">工资<br /></th><th class=\"top\" scope=\"col\">入职时间</th><th class=\"top\" scope=\"col\">操作</th><th class=\"top\" scope=\"col\">操作1</th></tr>");
		
		List<Emp> alluser=new EmpDaoJdbcImpl().findAll();
		System.out.println(alluser.size());
		for(int i=0;i<alluser.size();++i){
			
			out.println("<tr><th scope=\"row\">"+alluser.get(i).getId()+"" +
					"</th><td>"+alluser.get(i).getName()+"</td>" +
							"<td>"+alluser.get(i).getSal()+"</td>" +
									"<td>"+alluser.get(i).getHireDate().toString()
									+"</td><td><a href='empedit?id="+alluser.get(i).getId()+"'>修改</a></td>" +
											"<td><a href='empdelete?id="+alluser.get(i).getId()+"'>删除</a></td></tr>");
		}
		//out.println("<tr><th scope=\"row\">5092</th><td>张三</td><td>3000.0<br /></td><td>2009-10-09</td><td>2009-10-09</td></tr>");
		//out.println("<tr><th scope=\"row\">5093</th><td>李四<br /></td><td>3000.0</td><td>2009-02-21</td><td>2009-10-09</td></tr>");
		//out.println("<tr><th scope=\"row\">5095</th><td>王五</td><td>5000.0</td><td>2009-06-17</td><td>2009-10-09</td></tr>");
		
		
		
		out.println("</table>");
		out.println("<p class=\"caption\"><strong>表 1</strong> 员工列表</p>");
		out.println("</div> ");
		out.println(" ");
		out.println("</div>");
		out.println("</div>");
		out.println(" ");
		out.println("");
		out.println("<div class=\"footer\">");
		out.println("<p>Copyright &copy; 2010 tarena.com.cn | All Rights Reserved</p>");
		out.println("<p class=\"credits\"></p>");
		out.println("</div> ");
		out.println("</div> ");
		out.println(" ");
		out.println("</body>");
		out.println("</html>");



		
	}
}
