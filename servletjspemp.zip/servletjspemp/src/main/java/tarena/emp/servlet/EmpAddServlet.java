package tarena.emp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.Response;

import tarena.jdbc.DBUtil;

public class EmpAddServlet  extends HttpServlet{
	public static final  String EMP_ADD="insert into dept_lt values(dept_liu.nextval,?,?,?)";

	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1)
			throws ServletException, IOException {
		char[] allNum=(char[])this.getServletConfig().getServletContext().getAttribute("suijishu");
		System.out.println("char[] "+allNum);
	String oldN=new String(allNum);
	System.out.println(oldN+"_oldN");
	String newN=arg0.getParameter("yanzheng");
	System.err.println(newN+"_newN");
		if(!newN.equals(oldN))
		{
			arg1.setContentType("text/html;charset=GBK");
			PrintWriter out=arg1.getWriter();
			out.println("<html><body><center><h1>请输入验证码。。。。</h1></center></body></html>");
		return;	
		}
		else{
			String name=arg0.getParameter("name");
			String hireDate=arg0.getParameter("hireDate");
			String sal=arg0.getParameter("sal");
			System.out.println(name+"_"+hireDate+"_"+sal);
			try {
				Class.forName("oracle.jdbc.OracleDriver");
				String url="jdbc:oracle:thin:@192.168.0.23:1521:tarena";
				Connection con=DriverManager.getConnection(url,"xs01","xs01");
				//Connection con=DBUtil.open();
				PreparedStatement pst=con.prepareStatement(EMP_ADD);
				
				pst.setString(1, name);
				pst.setInt(2, Integer.parseInt(sal));
				pst.setString(3, hireDate);
				if(pst.executeUpdate()>0)
				{
					System.out.println("添加成功");
					arg1.sendRedirect("emplist");
					
				}else{
					System.out.println("添加失败");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	
	}

}
