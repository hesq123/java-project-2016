package tarena.emp.servlet;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tarena.emp.dao.DaoFactory;
import tarena.emp.dao.EmpDao;
import tarena.emp.dao.impl.EmpDaoJdbcImpl;
import tarena.emp.entity.Emp;

public class EmpEditServlet extends HttpServlet {
	//      /emp/EmpEditServlet
	@Override
	protected void service(
			HttpServletRequest request, 
			HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=GBK");
	int id=Integer.parseInt(request.getParameter("id"));
	Emp emp=new EmpDaoJdbcImpl().findById(id);
	
		PrintWriter out = response.getWriter();
		
		out.println("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">");
		out.println("<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\">");
		out.println(" ");
		out.println("<head>");
		out.println("<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" />");
		out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/layout2_setup.css\" />");
		out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/layout2_text.css\" />");
		out.println("<title></title>");
		out.println("</head>");
		out.println("");
		out.println("<!--[if IE]><style type=\"text/css\"> body {word-wrap: break-word;}</style><![endif]-->");
		out.println("");
		out.println("<body>");
		out.println("<div class=\"page-container\">");
		out.println("");
		out.println("");
		out.println("<div class=\"header\">");
		out.println(" ");
		out.println("<div class=\"header-middle\"> ");
		out.println(" ");
		out.println("<a class=\"sitelogo\" href=\"#\" title=\"Go to Start page\"></a>");
		out.println("<div class=\"sitename\">");
		out.println("<h1><a href=\"index.html\" title=\"Go to Start page\">TARENA<span style=\"font-weight:normal;font-size:50%;\">.com.cn</span></a></h1>");
		out.println("<h2>加拿大达内外企培训</h2>");
		out.println("</div>");
		out.println("");
		out.println("</div>");
		out.println(" ");
		out.println("<div class=\"header-bottom\">");
		out.println(" ");
		out.println("<div class=\"nav2\">");
		out.println(" ");
		out.println("<ul>");
		out.println("<li><a href=\"index.html\">系统首页</a></li>");
		out.println("</ul>");
		out.println(" ");
		out.println("<ul>");
		out.println("<li><a href=\"#\">员工管理<!--[if IE 7]><!--></a><!--<![endif]-->");
		out.println("<!--[if lte IE 6]><table><tr><td><![endif]-->");
		out.println("<ul>");
		out.println("<li><a href=\"#\">员工管理</a></li>");
		out.println("<li><a href=\"#\">添加员工</a></li>");
		out.println("</ul>");
		out.println("<!--[if lte IE 6]></td></tr></table></a><![endif]-->");
		out.println("</li>");
		out.println("</ul> ");
		out.println("");
		out.println("</div>");
		out.println("</div>");
		out.println("");
		out.println("");
		out.println("<div class=\"header-breadcrumbs\">");
		out.println("<ul>");
		out.println("<li><a href=\"#\">首页</a></li>");
		out.println("<li><a href=\"#\">员工管理</a></li>");
		out.println("<li>修改员工</li>");
		out.println("</ul>");
		out.println("");
		out.println(" ");
		out.println("</div>");
		out.println("</div>");
		out.println("");
		out.println("");
		out.println("<div class=\"main\">");
		out.println(" ");
		out.println("<div class=\"main-navigation\">");
		out.println("");
		out.println("<div class=\"round-border-topright\"></div>");
		out.println("<h1 class=\"first\">修改员工<br /></h1>");
		out.println("<p>修改员工信息并保存<br /></p>");
		out.println(" ");
		out.println("");
		out.println("");
		out.println(" ");
		out.println("</div>");
		out.println(" ");
		out.println("<div class=\"main-content\">");
		out.println(" ");
		out.println("<h1 class=\"pagetitle\">修改员工信息</h1>");
		out.println("");
		out.println(" ");
		out.println("");
		out.println(" ");
		out.println("<div class=\"column1-unit\">");
		out.println("<div class=\"contactform\">");
		out.println("            <form method=\"post\" action=\"empeditok\">  ");
		out.println("              <input type=\"hidden\" name=\"id\" value=\""+emp.getId()+"\"/>");
		out.println("              <fieldset><legend>&nbsp;基本信息&nbsp;</legend>");
		out.println("                <p><label for=\"name\" class=\"left\">姓名:</label>");
		out.println("                   <input type=\"text\" name=\"name\" id=\"name\" class=\"field\" value=\""+emp.getName()+"\" tabindex=\"1\" />");
		out.println("                   </p>");
		out.println("                ");
		out.println("                <p><label for=\"hire_date\" class=\"left\">入职时间:</label>");
		out.println("                   <input type=\"text\" name=\"hireDate\" id=\"hire_date\" class=\"field\" value=\""+emp.getHireDate()+"\" tabindex=\"1\" /></p>");
		out.println("                <p><label for=\"sal\" class=\"left\">薪水:</label>");
		out.println("                   <input type=\"text\" name=\"sal\" id=\"sal\" class=\"field\" value=\""+emp.getSal()+"\" tabindex=\"1\" /></p>");
		out.println("			");
		out.println("                <p><input type=\"submit\" name=\"submit\" id=\"submit\" class=\"button\" value=\"保存\" tabindex=\"6\" /></p>");
		out.println("              </fieldset>");
		out.println("              ");
		out.println("            </form>");
		out.println("          </div>");
		out.println("</div> ");
		out.println(" ");
		out.println("</div>");
		out.println("</div>");
		out.println(" ");
		out.println("");
		out.println("<div class=\"footer\">");
		out.println("<p>Copyright &copy; 2010 tarena.com.cn | All Rights Reserved</p>");
		out.println("<p class=\"credits\"></p>");
		out.println("</div> ");
		out.println("</div> ");
		out.println(" ");
		out.println("</body>");
		out.println("</html>");


	}
}
