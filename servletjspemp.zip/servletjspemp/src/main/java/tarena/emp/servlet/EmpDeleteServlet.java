package tarena.emp.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tarena.emp.dao.impl.EmpDaoJdbcImpl;
import tarena.emp.entity.Emp;

public class EmpDeleteServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1)
			throws ServletException, IOException {

		int id=Integer.parseInt(arg0.getParameter("id"));
		
		new EmpDaoJdbcImpl().delete(id);
		
			arg1.sendRedirect("emplist");

		
	
		
	}
	

}

