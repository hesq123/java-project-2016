package tarena.emp.dao;

import java.io.InputStream;
import java.util.Properties;

public class DaoFactory {
	public static <T> T getInstance(Class<T> c) {
		try {
			String s = c.getSimpleName();// abc.def.EmpDao-->EmpDao
			InputStream in = DaoFactory.class.getResourceAsStream(
					"/dao.properties");
			Properties prop = new Properties();
			prop.load(in);
			in.close();
			// 通过接口名得到对应的实现类类名
			String className = prop.getProperty(s);
			// 创建实现类实例
			return (T) Class.forName(className).newInstance();
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static void main(String[] args) {
		EmpDao dao = 
			DaoFactory.getInstance(EmpDao.class);
		System.out.println(dao);
	}
}


