package tarena.emp.dao.impl;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ImageServlet extends HttpServlet{
//��֤��ͼƬ
	/**
	 * 
	 * */
	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1)
			throws ServletException, IOException {
		arg1.setContentType("image/jpeg");
		OutputStream os=arg1.getOutputStream();
		//���������Ļ���ķ���
		arg1.setHeader("progma", "no-cache");
		arg1.setHeader("Cache-Control", "no-cache");
		arg1.setDateHeader("Expires", 0);
		String num="1234567890";
		char[] allnum=new char[4];
		for(int i=0;i<allnum.length;i++)
		{
			int index=(int)(Math.random()*10);
			allnum[i]=num.charAt(index);
			
		}
		this.getServletConfig().getServletContext().setAttribute("suijishu", allnum);
		BufferedImage image=new BufferedImage(100, 50, BufferedImage.TYPE_INT_BGR);//����һ������
		Graphics g=image.getGraphics();//����
		g.setColor(Color.pink);//��ͼ������ɫ
		g.drawRect(400, 300, 100, 50);//��ͼ������״
		g.setColor(Color.cyan);
		for(int i=0;i<allnum.length;i++)
		{
			g.drawString(""+allnum[i], i*20+10, 20);//������
		}
		g.dispose();
		ByteArrayOutputStream bo=new ByteArrayOutputStream();
		ImageIO.write(image, "JPEG", bo);
		byte[] b=bo.toByteArray();
		os.write(b);
		bo.close();
		os.flush();
		
		
		
		
		
	}

}
