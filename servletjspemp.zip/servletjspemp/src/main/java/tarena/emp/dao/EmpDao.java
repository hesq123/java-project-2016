package tarena.emp.dao;

import java.util.List;

import tarena.emp.entity.Emp;

public interface EmpDao {
	public void save(Emp emp) throws Exception ;
	public void delete(int id) ;
	public Boolean deleteByIds(int[] id) throws Exception;
	public boolean update(Emp emp);
	public Emp findById(int id) ;
	public List<Emp> findAll() throws Exception;
	
}
