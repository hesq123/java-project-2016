package tarena.emp.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import tarena.emp.dao.EmpDao;
import tarena.emp.entity.Emp;

public class EmpDaoJdbcImpl implements EmpDao {
	public static Connection getJDBC(){
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			String url="jdbc:oracle:thin:@192.168.0.23:1521:tarena";
		 con=DriverManager.getConnection(url,"xs01","xs01");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}

	public void delete(int id)  {
		String sql="delete dept_lt where id=?";
		Connection con=EmpDaoJdbcImpl.getJDBC();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			if(pst.executeUpdate()>0)
			{
				System.out.println("删除成功");
			}
			else{
				System.out.println("删除失败");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	public Boolean deleteByIds(int[] id)  {
		
		
		return false;
		
		
	}

	public List<Emp> findAll() {
		List<Emp> list = new ArrayList<Emp>();
		String sql = "select * from dept_lt";
		Connection con = EmpDaoJdbcImpl.getJDBC();
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				
				Emp emp=new Emp();
				emp.setId(rs.getInt(1));
				emp.setName(rs.getString(2));
				emp.setSal(rs.getInt(3));
				emp.setHireDate(rs.getString(4));
				list.add(emp);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public Emp findById(int id){
		Emp emp=new Emp();
		emp.setId(id);
		String sql = 
			"select * from dept_lt where id=?";
		Connection con = EmpDaoJdbcImpl.getJDBC();
	PreparedStatement pst;
	
	try {
		pst = con.prepareStatement(sql);
		pst.setInt(1, id);
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			emp.setHireDate(rs.getString(4));
			emp.setName(rs.getString(2));
			emp.setSal(Double.parseDouble(rs.getString(3)));
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return emp;


	}

	public void save(Emp emp) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public boolean update(Emp emp){
		
		Connection con=EmpDaoJdbcImpl.getJDBC();
		String sql="update dept_lt set name=?,sal=?,hiredate=? where id=?";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, emp.getName());
			pst.setDouble(2, emp.getSal());
			pst.setString(3, emp.getHireDate().toString());
			pst.setInt(4,emp.getId());
			if(pst.executeUpdate()>0)
			{
				System.out.println("修改成功");
				return true;
				
			}else{
				System.out.println("修改失败");
				
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

}
