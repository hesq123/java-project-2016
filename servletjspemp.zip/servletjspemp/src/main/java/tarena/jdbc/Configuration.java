package tarena.jdbc;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class Configuration {
  private String url;
  private String driver;
  private String username;
  private String password;
  
  
  
  private int initialSize;
  private int maxActive;
  private int maxIdle;
  private long maxWait;
  private String validationQuery;
  
  public int getInitialSize() {
    return initialSize;
  }
  public void setInitialSize(int initialSize) {
    this.initialSize = initialSize;
  }
  public int getMaxActive() {
    return maxActive;
  }
  public void setMaxActive(int maxActive) {
    this.maxActive = maxActive;
  }
  public int getMaxIdle() {
    return maxIdle;
  }
  public void setMaxIdle(int maxIdle) {
    this.maxIdle = maxIdle;
  }
  public long getMaxWait() {
    return maxWait;
  }
  public void setMaxWait(long maxWait) {
    this.maxWait = maxWait;
  }
  public String getValidationQuery() {
    return validationQuery;
  }
  public void setValidationQuery(String validationQuery) {
    this.validationQuery = validationQuery;
  }
  public Configuration() {
  }
  public Configuration(String url, String driver, String username, String password) {
    super();
    this.url = url;
    this.driver = driver;
    this.username = username;
    this.password = password;
  }
  public String getDriver() {
    return driver;
  }
  public void setDriver(String driver) {
    this.driver = driver;
  }
  public String getPassword() {
    return password;
  }
  public void setPassword(String password) {
    this.password = password;
  }
  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }
  public String getUsername() {
    return username;
  }
  public void setUsername(String username) {
    this.username = username;
  }
  
  /**
   * 读取配置文件
   * 生成Configuration对象
   * 默认配置文件是类路径中的 db.xml
   */
  public static Configuration configure() {
    try {
      InputStream in = 
        Configuration.class.getResourceAsStream("/db.xml");
      Configuration cfg = load(in);
      return cfg;
    } catch (Exception e) {
      e.printStackTrace();
      return null;// 无法加载配置信息，返回Null
    }    
  }  
  /**
   * 指定配置文件加载配置信息 
   */
  public static Configuration configure(File configFile) {
    try {
      InputStream in = 
        new FileInputStream(configFile);
      Configuration cfg = load(in);
      return cfg;
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

  private static Configuration load(InputStream in) throws DocumentException {
    SAXReader reader = new SAXReader();
    Document doc = reader.read(in);
    Element jdbc = doc.getRootElement();
    String url = jdbc.element("url").getText();
    String driver = jdbc.element("driver").getText();
    String username = jdbc.element("username").getText();
    String password = jdbc.element("password").getText();
    
    Configuration cfg = new Configuration(url, driver, username, password);

    Element dbcp = jdbc.element("dbcp");
    cfg.setInitialSize(
        Integer.parseInt(dbcp.element("initialSize").getText()));
    cfg.setMaxActive(
        Integer.parseInt(dbcp.element("maxActive").getText()));
    cfg.setMaxIdle(
        Integer.parseInt(dbcp.element("maxIdle").getText()));
    cfg.setMaxWait(
        Long.parseLong(dbcp.element("maxWait").getText()));
    cfg.setValidationQuery(
        dbcp.element("validationQuery").getText());
    
    return cfg;
  }
  
  public static void main(String[] args) {
    Configuration cfg = Configuration.configure();
    System.out.println(cfg.getUrl());
    System.out.println(cfg.getDriver());
    System.out.println(cfg.getUsername());
    System.out.println(cfg.getPassword());
    System.out.println(cfg.getValidationQuery());
  }
}
