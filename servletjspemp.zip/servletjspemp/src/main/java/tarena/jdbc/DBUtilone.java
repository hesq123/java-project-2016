package tarena.jdbc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
public class DBUtilone {
	private static String driver,uri,user,password;
	static{
		Properties my=new Properties();
		try {
		//	my.load(new FileInputStream("src/JDBC/properties.txt"));
			my.load(DBUtilone.class.getClassLoader().getResourceAsStream("JDBC/properties.txt"));
			driver=my.getProperty("driver");
			uri=my.getProperty("uri");
			user=my.getProperty("user");
			password=my.getProperty("pwd");
			Class.forName(driver);
			
		/*	System.out.println(driver);
			System.out.println(uri);
			System.out.println(user);
			System.out.println(password);*/
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static Connection getConnection() throws Exception{
		Connection connection=null;

			
	       connection=DriverManager.getConnection(uri,user,password);
			
		
		return connection;
	}
	/*public static void main(String[] args)
	{

		try {
			System.out.println(new ConnectionUtils().getConnection());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	}
